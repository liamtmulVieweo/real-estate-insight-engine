import { useState } from "react";
import type { AnalysisSummary } from "@/types/brokerage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, AlertCircle, Unlock } from "lucide-react";

interface SummarySectionProps {
  summary: {
    blocking_issues: string[];
    key_unlocks: string[];
  };
  analysisSummary: AnalysisSummary;
}

export function SummarySection({ summary, analysisSummary }: SummarySectionProps) {
  const [issuesOpen, setIssuesOpen] = useState(false);
  const [unlocksOpen, setUnlocksOpen] = useState(false);
  const [conclusionOpen, setConclusionOpen] = useState(false);

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-medium">Summary</h3>
      
      <div className="grid gap-3 sm:grid-cols-2">
        <Collapsible open={issuesOpen} onOpenChange={setIssuesOpen}>
          <Card className="border-l-4 border-l-[hsl(var(--status-danger))]">
            <CollapsibleTrigger className="w-full text-left">
              <CardHeader className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-status-danger" />
                    <CardTitle className="text-sm font-medium">Key Issues</CardTitle>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-medium text-status-danger">{summary.blocking_issues.length}</span>
                    <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
                  </div>
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="px-4 pb-4 pt-0">
                <ul className="text-sm space-y-1.5">
                  {(summary.blocking_issues || []).map((issue, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-status-danger shrink-0">•</span>
                      <span>{issue}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        <Collapsible open={unlocksOpen} onOpenChange={setUnlocksOpen}>
          <Card className="border-l-4 border-l-[hsl(var(--status-success))]">
            <CollapsibleTrigger className="w-full text-left">
              <CardHeader className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Unlock className="h-4 w-4 text-status-success" />
                    <CardTitle className="text-sm font-medium">Key Wins</CardTitle>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-medium text-status-success">{summary.key_unlocks.length}</span>
                    <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
                  </div>
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="px-4 pb-4 pt-0">
                <ul className="text-sm space-y-1.5">
                  {(summary.key_unlocks || []).map((unlock, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-status-success shrink-0">✓</span>
                      <span>{unlock}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>
      </div>

      <Collapsible open={conclusionOpen} onOpenChange={setConclusionOpen}>
        <Card className="border">
          <CollapsibleTrigger className="w-full text-left">
            <CardHeader className="p-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Analysis Conclusion</CardTitle>
                <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
              </div>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="px-4 pb-4 pt-0 space-y-4">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">Current Visibility</p>
                <ul className="text-sm space-y-1">
                  {(analysisSummary.visibility_snapshot || []).map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-muted-foreground">
                      <span className="shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">Focus Areas</p>
                <ul className="text-sm space-y-1">
                  {(analysisSummary.fix_categories || []).map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-muted-foreground">
                      <span className="shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Bottom Line</p>
                <p className="text-sm">{analysisSummary.conclusion}</p>
              </div>
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    </div>
  );
}
