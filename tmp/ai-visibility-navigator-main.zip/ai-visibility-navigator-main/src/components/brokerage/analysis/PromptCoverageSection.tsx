import { useState } from "react";
import type { PromptCoverage } from "@/types/brokerage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle, ChevronDown } from "lucide-react";

interface PromptCoverageSectionProps {
  coverage: PromptCoverage;
}

export function PromptCoverageSection({ coverage }: PromptCoverageSectionProps) {
  const [openSection, setOpenSection] = useState<string | null>(null);

  const sections = [
    {
      key: "supported",
      title: "Covered",
      description: "Prompts where your brokerage could appear",
      items: coverage.supported || [],
      icon: <CheckCircle2 className="h-4 w-4 text-status-success" />,
      countClass: "text-status-success",
    },
    {
      key: "missing",
      title: "Gaps",
      description: "Prompts with missing information",
      items: coverage.missing || [],
      icon: <AlertTriangle className="h-4 w-4 text-status-warning" />,
      countClass: "text-status-warning",
    },
    {
      key: "blocked",
      title: "Not Yet Eligible",
      description: "Content needed before AI recommends you",
      items: coverage.blocked || [],
      icon: <XCircle className="h-4 w-4 text-muted-foreground" />,
      countClass: "text-muted-foreground",
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <h3 className="text-sm font-medium">Prompt Coverage</h3>
        <Popover>
          <PopoverTrigger>
            <HelpCircle className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground cursor-pointer" />
          </PopoverTrigger>
          <PopoverContent side="top" className="w-72 text-sm bg-popover">
            <p className="font-medium mb-1">What are intent anchors?</p>
            <p className="text-muted-foreground text-xs leading-relaxed">
              Intent anchors are the key phrases and context that AI assistants use to match user queries with relevant businesses. Strong anchors include property types, markets, and specific services.
            </p>
          </PopoverContent>
        </Popover>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        {sections.map((section) => (
          <Collapsible 
            key={section.key} 
            open={openSection === section.key}
            onOpenChange={(open) => setOpenSection(open ? section.key : null)}
          >
            <Card className="border">
              <CollapsibleTrigger className="w-full text-left">
                <CardHeader className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {section.icon}
                      <div>
                        <CardTitle className="text-sm font-medium">{section.title}</CardTitle>
                        <p className="text-xs text-muted-foreground">{section.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className={`text-lg font-semibold ${section.countClass}`}>
                        {section.items.length}
                      </span>
                      <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
                    </div>
                  </div>
                </CardHeader>
              </CollapsibleTrigger>
              
              <CollapsibleContent>
                <CardContent className="px-4 pb-4 pt-0">
                  {section.items.length > 0 ? (
                    <ul className="text-sm space-y-1.5">
                      {section.items.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-muted-foreground">
                          <span className="text-muted-foreground/50 shrink-0">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-muted-foreground italic">None found</p>
                  )}
                </CardContent>
              </CollapsibleContent>
            </Card>
          </Collapsible>
        ))}
      </div>
    </div>
  );
}
