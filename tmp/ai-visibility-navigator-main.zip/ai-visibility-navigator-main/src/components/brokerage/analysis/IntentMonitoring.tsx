import { useState } from "react";
import type { IntentCoverage } from "@/types/brokerage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { CheckCircle2, AlertTriangle, XCircle, ChevronDown } from "lucide-react";

interface IntentMonitoringProps {
  intents: IntentCoverage[];
}

function statusBadge(status: string) {
  switch (status) {
    case "Eligible":
      return (
        <Badge className="bg-status-success-bg text-status-success-foreground border-0 gap-1 text-xs font-medium">
          <CheckCircle2 className="h-3 w-3" />
          Eligible
        </Badge>
      );
    case "Needs Work":
    case "Partially Blocked":
      return (
        <Badge className="bg-status-warning-bg text-status-warning-foreground border-0 gap-1 text-xs font-medium">
          <AlertTriangle className="h-3 w-3" />
          Needs Work
        </Badge>
      );
    default:
      return (
        <Badge className="bg-muted text-muted-foreground border-0 gap-1 text-xs font-medium">
          <XCircle className="h-3 w-3" />
          Not Yet Eligible
        </Badge>
      );
  }
}

export function IntentMonitoring({ intents }: IntentMonitoringProps) {
  const [openItems, setOpenItems] = useState<Set<string>>(new Set());

  const toggle = (id: string) => {
    const newSet = new Set(openItems);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setOpenItems(newSet);
  };

  return (
    <section className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold">Prompt Monitoring</h2>
        <p className="text-sm text-muted-foreground mt-1">
          How AI assistants respond when users ask about services like yours
        </p>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {(intents || []).map((intent) => (
          <Collapsible 
            key={intent.intent_name} 
            open={openItems.has(intent.intent_name)}
            onOpenChange={() => toggle(intent.intent_name)}
          >
            <Card className="border">
              <CollapsibleTrigger className="w-full text-left">
                <CardHeader className="p-4 pb-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-sm font-medium">{intent.intent_name}</CardTitle>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {statusBadge(intent.status)}
                      <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
                    </div>
                  </div>
                </CardHeader>
              </CollapsibleTrigger>
              
              <CollapsibleContent>
                <CardContent className="px-4 pb-4 pt-0 space-y-4">
                  <div>
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">Example Prompts</p>
                    <ul className="text-sm space-y-1.5">
                      {(intent.prompts || []).map((prompt, i) => (
                        <li key={i} className="flex items-start gap-2 text-muted-foreground">
                          <span className="text-muted-foreground/50 shrink-0">"</span>
                          <span className="italic">{prompt}</span>
                          <span className="text-muted-foreground/50 shrink-0">"</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  {(intent.solution_fixes || []).length > 0 && (
                    <div className="border-t pt-3">
                      <p className="text-xs font-medium text-status-success uppercase tracking-wide mb-2">How to Fix</p>
                      <div className="space-y-2">
                        {(intent.solution_fixes || []).map((fix, i) => (
                          <div key={i} className="text-sm">
                            <span className="font-medium">{fix.fix_name}:</span>
                            <span className="text-muted-foreground"> {fix.description}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </CollapsibleContent>
            </Card>
          </Collapsible>
        ))}
      </div>
    </section>
  );
}
