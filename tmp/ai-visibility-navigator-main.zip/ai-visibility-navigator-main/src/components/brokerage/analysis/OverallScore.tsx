import type { SALTPillarScore } from "@/types/brokerage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, Globe, Award, MapPin, Shield } from "lucide-react";

interface OverallScoreProps {
  score: number;
  saltScores: SALTPillarScore[];
}

function scoreColor(score: number) {
  if (score >= 70) return "text-status-success";
  if (score >= 50) return "text-status-warning";
  return "text-status-danger";
}

function scoreBorderColor(score: number) {
  if (score >= 70) return "border-l-[hsl(var(--status-success))]";
  if (score >= 50) return "border-l-[hsl(var(--status-warning))]";
  return "border-l-[hsl(var(--status-danger))]";
}

function pillarIcon(pillar: string) {
  const iconClass = "h-4 w-4";
  switch (pillar) {
    case "Semantic": return <Globe className={iconClass} />;
    case "Authority": return <Award className={iconClass} />;
    case "Location": return <MapPin className={iconClass} />;
    case "Trust": return <Shield className={iconClass} />;
    default: return null;
  }
}

function pillarDescription(pillar: string) {
  switch (pillar) {
    case "Semantic": return "How clearly your firm's focus is communicated";
    case "Authority": return "Evidence of expertise through deals and results";
    case "Location": return "Geographic clarity for markets you serve";
    case "Trust": return "Credibility signals for AI recommendations";
    default: return "";
  }
}

export function OverallScore({ score, saltScores }: OverallScoreProps) {
  return (
    <section className="space-y-8">
      <div className="text-center space-y-1">
        <p className="text-sm font-medium text-muted-foreground">AI Visibility Score</p>
        <div className={`text-6xl font-bold tracking-tight ${scoreColor(score)}`}>{score}</div>
        <p className="text-sm text-muted-foreground">out of 100</p>
      </div>

      <div className="space-y-4">
        <div className="text-center">
          <h3 className="text-sm font-medium">SALT Framework</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            How AI assistants evaluate your brokerage
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          {saltScores.map((s) => (
            <Collapsible key={s.pillar}>
              <Card className={`border-l-4 ${scoreBorderColor(s.score)}`}>
                <CollapsibleTrigger className="w-full text-left">
                  <CardHeader className="p-4 pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="text-muted-foreground">
                          {pillarIcon(s.pillar)}
                        </div>
                        <div>
                          <CardTitle className="text-sm font-medium">{s.pillar}</CardTitle>
                          <p className="text-xs text-muted-foreground">{pillarDescription(s.pillar)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xl font-semibold ${scoreColor(s.score)}`}>{s.score}</span>
                        <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
                      </div>
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <CardContent className="px-4 pb-4 pt-0 space-y-2">
                    <p className="text-sm">{s.summary}</p>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {s.details.map((d, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-muted-foreground/50 shrink-0">•</span>
                          <span>{d}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          ))}
        </div>
      </div>
    </section>
  );
}
