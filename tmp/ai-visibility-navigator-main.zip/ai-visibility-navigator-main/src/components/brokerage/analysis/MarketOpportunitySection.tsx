import { useState } from "react";
import type { MarketOpportunity } from "@/types/brokerage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { MapPin, ChevronDown } from "lucide-react";

interface MarketOpportunitySectionProps {
  opportunity: MarketOpportunity;
}

export function MarketOpportunitySection({ opportunity }: MarketOpportunitySectionProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card className="border">
        <CollapsibleTrigger className="w-full text-left">
          <CardHeader className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <MapPin className="h-4 w-4 text-primary" />
                <div>
                  <CardTitle className="text-sm font-medium">Market Content Opportunity</CardTitle>
                  <p className="text-xs text-muted-foreground">{opportunity.submarket}</p>
                </div>
              </div>
              <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <CardContent className="px-4 pb-4 pt-0 space-y-4">
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Suggested Page Title</p>
              <p className="text-sm font-medium">{opportunity.suggested_title}</p>
            </div>
            
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Content Structure</p>
              <p className="text-sm text-muted-foreground">{opportunity.headings_description}</p>
            </div>
            
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">Include</p>
              <ul className="text-sm space-y-1">
                {(opportunity.required_content || []).map((item, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-status-success shrink-0">✓</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <p className="text-xs font-medium text-status-danger-foreground uppercase tracking-wide mb-2">Avoid</p>
              <ul className="text-sm space-y-1">
                {(opportunity.avoid || []).map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-status-danger shrink-0">✕</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}
