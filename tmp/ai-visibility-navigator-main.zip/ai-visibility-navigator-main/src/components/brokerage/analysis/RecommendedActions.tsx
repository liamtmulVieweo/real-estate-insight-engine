import { useState } from "react";
import type { RecommendedAction } from "@/types/brokerage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Globe, Award, MapPin, Shield, ExternalLink, ChevronDown, ChevronUp } from "lucide-react";

interface RecommendedActionsProps {
  actions: RecommendedAction[];
}

function priorityBadge(priority: string) {
  switch (priority) {
    case "high":
      return <Badge className="bg-status-danger-bg text-status-danger-foreground border-0 text-xs font-medium">High Priority</Badge>;
    case "medium":
      return <Badge className="bg-status-warning-bg text-status-warning-foreground border-0 text-xs font-medium">Medium</Badge>;
    default:
      return <Badge className="bg-status-success-bg text-status-success-foreground border-0 text-xs font-medium">Lower</Badge>;
  }
}

function pillarIcon(pillar: string) {
  const iconClass = "h-3.5 w-3.5";
  switch (pillar) {
    case "Semantic": return <Globe className={iconClass} />;
    case "Authority": return <Award className={iconClass} />;
    case "Location": return <MapPin className={iconClass} />;
    case "Trust": return <Shield className={iconClass} />;
    default: return null;
  }
}

function UrlLink({ url }: { url: string }) {
  const isValidUrl = url.startsWith("http://") || url.startsWith("https://") || url.startsWith("/");
  
  if (!isValidUrl) {
    return <span>{url}</span>;
  }

  return (
    <a 
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="text-primary hover:underline inline-flex items-center gap-1"
    >
      {url}
      <ExternalLink className="h-3 w-3" />
    </a>
  );
}

export function RecommendedActions({ actions }: RecommendedActionsProps) {
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());

  const toggle = (id: string) => {
    const newSet = new Set(expandedItems);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setExpandedItems(newSet);
  };

  // Sort by priority: high first, then medium, then low
  const sortedActions = [...(actions || [])].sort((a, b) => {
    const order = { high: 0, medium: 1, low: 2 };
    return order[a.priority] - order[b.priority];
  });

  return (
    <section className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold">Priority Fixes</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Actionable recommendations sorted by impact on AI visibility
        </p>
      </div>
      
      <div className="space-y-3">
        {sortedActions.map((a) => {
          const isExpanded = expandedItems.has(a.title);
          
          return (
            <Card key={a.title} className="border">
              <Collapsible open={isExpanded} onOpenChange={() => toggle(a.title)}>
                <CollapsibleTrigger className="w-full text-left">
                  <CardHeader className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-base font-medium leading-snug">{a.title}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{a.issue}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {isExpanded ? (
                          <ChevronUp className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap mt-3">
                      <Badge variant="secondary" className="text-xs gap-1">
                        {pillarIcon(a.pillar)}
                        {a.pillar}
                      </Badge>
                      {priorityBadge(a.priority)}
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>
                
                <CollapsibleContent>
                  <CardContent className="px-4 pb-4 pt-0 space-y-4">
                    {a.affected_urls && a.affected_urls.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Affected Pages</p>
                        <div className="flex flex-wrap gap-2">
                          {a.affected_urls.map((url, i) => (
                            <span key={i} className="text-sm">
                              <UrlLink url={url} />
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Why This Matters</p>
                      <p className="text-sm text-muted-foreground">{a.why_it_matters}</p>
                    </div>
                    
                    <div>
                      <p className="text-xs font-medium text-status-success uppercase tracking-wide mb-2">What To Do</p>
                      <ol className="text-sm space-y-1.5 list-decimal list-inside">
                        {(a.what_to_do || []).map((step, i) => (
                          <li key={i} className="leading-relaxed">{step}</li>
                        ))}
                      </ol>
                    </div>
                    
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">How You Know It's Done</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {(a.how_to_know_done || []).map((item, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-status-success">✓</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          );
        })}
      </div>
    </section>
  );
}
