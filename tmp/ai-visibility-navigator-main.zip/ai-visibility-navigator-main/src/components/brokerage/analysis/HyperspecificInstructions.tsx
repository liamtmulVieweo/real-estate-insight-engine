import { useState } from "react";
import type { HyperspecificInstruction } from "@/types/brokerage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ExternalLink, Zap, Clock, ChevronDown, ChevronUp } from "lucide-react";

interface HyperspecificInstructionsProps {
  instructions: HyperspecificInstruction[];
}

function impactBadge(impact: string) {
  switch (impact) {
    case "high":
      return <Badge className="bg-status-danger-bg text-status-danger-foreground border-0 gap-1 text-xs"><Zap className="h-3 w-3" />High Impact</Badge>;
    case "medium":
      return <Badge className="bg-status-warning-bg text-status-warning-foreground border-0 text-xs">Medium</Badge>;
    default:
      return <Badge variant="secondary" className="border-0 text-xs">Low</Badge>;
  }
}

function effortBadge(effort: string) {
  switch (effort) {
    case "low":
      return <Badge variant="outline" className="gap-1 text-xs"><Clock className="h-3 w-3" />Quick</Badge>;
    case "medium":
      return <Badge variant="outline" className="gap-1 text-xs"><Clock className="h-3 w-3" />Medium</Badge>;
    default:
      return <Badge variant="outline" className="gap-1 text-xs"><Clock className="h-3 w-3" />Longer</Badge>;
  }
}

function UrlLink({ url }: { url: string }) {
  const isValidUrl = url.startsWith("http://") || url.startsWith("https://") || url.startsWith("/");
  
  if (!isValidUrl) {
    return <span className="text-sm text-muted-foreground">{url}</span>;
  }

  return (
    <a 
      href={url.startsWith("/") ? url : url}
      target="_blank"
      rel="noopener noreferrer"
      className="text-sm text-primary hover:underline inline-flex items-center gap-1"
    >
      {url}
      <ExternalLink className="h-3 w-3" />
    </a>
  );
}

export function HyperspecificInstructions({ instructions }: HyperspecificInstructionsProps) {
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());

  const toggle = (id: string) => {
    const newSet = new Set(expandedItems);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setExpandedItems(newSet);
  };

  return (
    <section className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold">Implementation Playbook</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Step-by-step instructions your team can follow to improve visibility
        </p>
      </div>
      
      <div className="space-y-3">
        {(instructions || []).map((inst) => {
          const isExpanded = expandedItems.has(inst.title);
          
          return (
            <Card key={inst.title} className="border">
              <Collapsible open={isExpanded} onOpenChange={() => toggle(inst.title)}>
                <CollapsibleTrigger className="w-full text-left">
                  <CardHeader className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-base font-medium leading-snug">{inst.title}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">{inst.deliverable}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge className="bg-primary/10 text-primary border-0 text-xs">
                          +{inst.salt_points} points
                        </Badge>
                        {isExpanded ? (
                          <ChevronUp className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap mt-3">
                      {impactBadge(inst.impact)}
                      {inst.effort && effortBadge(inst.effort)}
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>
                
                <CollapsibleContent>
                  <CardContent className="px-4 pb-4 pt-0 space-y-5">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div>
                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Target Search Intent</p>
                        <p className="text-sm italic">"{inst.target_intent}"</p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Target Page</p>
                        <UrlLink url={inst.target_url} />
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Suggested Page Title</p>
                      <p className="text-sm font-medium">{inst.suggested_title}</p>
                    </div>
                    
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">What To Do</p>
                      <ol className="text-sm space-y-2 list-decimal list-inside">
                        {(inst.action_items || []).map((a, i) => (
                          <li key={i} className="leading-relaxed">{a}</li>
                        ))}
                      </ol>
                    </div>
                    
                    <div>
                      <p className="text-xs font-medium text-status-danger-foreground uppercase tracking-wide mb-2">Avoid</p>
                      <ul className="text-sm space-y-1">
                        {(inst.avoid || []).map((a, i) => (
                          <li key={i} className="flex items-start gap-2 text-muted-foreground">
                            <span className="text-status-danger">✕</span>
                            <span>{a}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    {inst.good_example && (
                      <div className="bg-muted/50 rounded-md p-3">
                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">Good Example</p>
                        <p className="text-sm text-muted-foreground">{inst.good_example}</p>
                      </div>
                    )}
                    
                    <div className="text-xs text-muted-foreground border-t pt-3 space-y-1">
                      <p><span className="font-medium">Expected Result:</span> {inst.effect}</p>
                      {inst.dependency && (
                        <p><span className="font-medium">Depends On:</span> {inst.dependency}</p>
                      )}
                    </div>
                  </CardContent>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          );
        })}
      </div>
    </section>
  );
}
