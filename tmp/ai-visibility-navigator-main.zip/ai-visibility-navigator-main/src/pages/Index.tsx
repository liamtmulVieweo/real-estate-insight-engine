import { Building2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScanForm } from "@/components/brokerage/ScanForm";
import { ScanLoading } from "@/components/brokerage/ScanLoading";
import { LedgerEditor } from "@/components/brokerage/LedgerEditor";
import { AnalysisView } from "@/components/brokerage/AnalysisView";
import { useBrokerageScan } from "@/hooks/useBrokerageScan";

const Index = () => {
  const { scanResult, analysisResult, isScanning, isAnalyzing, error, scan, analyze } = useBrokerageScan();

  const activeTab = analysisResult ? "analysis" : scanResult ? "ledger" : "overview";

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container max-w-4xl flex items-center gap-2.5 h-14">
          <Building2 className="h-5 w-5 text-primary" />
          <h1 className="text-base font-semibold">AI Visibility Dashboard</h1>
        </div>
      </header>

      <main className="container max-w-4xl py-8 px-4">
        <Tabs value={activeTab} className="space-y-6">
          <TabsList className="bg-muted/50">
            <TabsTrigger value="overview" className="text-sm">Overview</TabsTrigger>
            <TabsTrigger value="ledger" disabled={!scanResult} className="text-sm">Ledger</TabsTrigger>
            <TabsTrigger value="analysis" disabled={!analysisResult} className="text-sm">Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            <div className="text-center space-y-3 pt-6">
              <h2 className="text-2xl font-semibold tracking-tight">Check your AI visibility</h2>
              <p className="text-muted-foreground max-w-md mx-auto text-sm leading-relaxed">
                Discover how AI assistants see and recommend your brokerage. Get actionable fixes to improve your visibility.
              </p>
            </div>
            {isScanning ? (
              <ScanLoading />
            ) : (
              <ScanForm onScan={scan} isLoading={isScanning} />
            )}
            {error && (
              <p className="text-center text-sm text-destructive">{error}</p>
            )}
          </TabsContent>

          <TabsContent value="ledger">
            {scanResult && (
              <LedgerEditor scanResult={scanResult} onSave={analyze} isAnalyzing={isAnalyzing} />
            )}
            {isAnalyzing && <ScanLoading label="Running analysis…" />}
            {error && <p className="text-sm text-destructive mt-4">{error}</p>}
          </TabsContent>

          <TabsContent value="analysis">
            {analysisResult && <AnalysisView analysis={analysisResult} />}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Index;
