import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const LEDGER_KEYS = [
  { key: "brokerage_name", label: "Brokerage Name" },
  { key: "property_type", label: "Property Type" },
  { key: "markets_served", label: "Markets Served" },
  { key: "submarkets", label: "Key Submarkets" },
  { key: "services", label: "Services Offered" },
  { key: "team_size", label: "Team Size / Key People" },
  { key: "deal_examples", label: "Deal Examples / Case Studies" },
  { key: "client_types", label: "Client Types" },
  { key: "specializations", label: "Specializations" },
  { key: "geographic_focus", label: "Geographic Focus" },
  { key: "years_in_business", label: "Years in Business" },
  { key: "affiliations", label: "Affiliations / Networks" },
  { key: "testimonials", label: "Testimonials / Social Proof" },
  { key: "market_insights", label: "Market Insights / Reports" },
  { key: "unique_value", label: "Unique Value Proposition" },
];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { url } = await req.json();
    if (!url) {
      return new Response(JSON.stringify({ error: "URL is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const questionsBlock = LEDGER_KEYS.map(
      (k) => `- "${k.key}" (${k.label})`
    ).join("\n");

    const systemPrompt = `You are a commercial real estate research analyst. Given a brokerage website URL, extract key information about the firm. Return a JSON object with these exact fields:
- "brokerage_name": the firm's name
- "website_url": the URL provided
- "results": an array of objects, each with "key", "label", and "answer"

The keys and labels to extract:
${questionsBlock}

If you cannot find information for a field, set the answer to "Not found".
Return ONLY valid JSON, no markdown fences or extra text.`;

    console.log("Scanning URL:", url);

    const response = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: systemPrompt },
            {
              role: "user",
              content: `Extract brokerage information from this website: ${url}. Based on what you know or can infer about this brokerage from the URL and domain name, provide the best answers you can for each field.`,
            },
          ],
          tools: [
            {
              type: "function",
              function: {
                name: "extract_brokerage_data",
                description:
                  "Return extracted brokerage information as structured data",
                parameters: {
                  type: "object",
                  properties: {
                    brokerage_name: { type: "string" },
                    website_url: { type: "string" },
                    results: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          key: { type: "string" },
                          label: { type: "string" },
                          answer: { type: "string" },
                        },
                        required: ["key", "label", "answer"],
                        additionalProperties: false,
                      },
                    },
                  },
                  required: ["brokerage_name", "website_url", "results"],
                  additionalProperties: false,
                },
              },
            },
          ],
          tool_choice: {
            type: "function",
            function: { name: "extract_brokerage_data" },
          },
        }),
      }
    );

    if (!response.ok) {
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage limit reached. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      throw new Error(`AI gateway returned ${response.status}`);
    }

    const aiData = await response.json();
    console.log("AI response received");

    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      throw new Error("No structured response from AI");
    }

    const extracted = JSON.parse(toolCall.function.arguments);
    console.log("Extracted brokerage:", extracted.brokerage_name);

    return new Response(JSON.stringify(extracted), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("gemini-lookup error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
