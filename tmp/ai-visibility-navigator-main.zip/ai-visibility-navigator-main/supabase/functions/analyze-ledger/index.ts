import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { brokerage_name, website_url, results } = await req.json();
    if (!brokerage_name || !results) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const ledgerText = results
      .map((r: any) => `${r.label}: ${r.answer}`)
      .join("\n");

    const systemPrompt = `You are an AI visibility analyst for commercial real estate brokerages. You write for a brokerage owner or head of marketing—not a technical audience.

CRITICAL WRITING GUIDELINES:
- Use plain English that a brokerage principal would understand immediately
- Be hyperspecific: mention actual page URLs, exact phrases to add, specific content to create
- Never use jargon like "semantic positioning" or "entity clarity" without explaining it
- Focus on WHAT to do and WHY it helps get more leads
- Priority labels must be "high", "medium", or "low"

SALT FRAMEWORK (4 pillars):
1. Semantic - How clearly your firm describes its focus, services, and specializations
2. Authority - Evidence of expertise through deals, track record, and results  
3. Location - Geographic clarity for markets and submarkets served
4. Trust - Credibility signals that make AI confident recommending you

Return structured data using the provided tool.`;

    const userPrompt = `Analyze this CRE brokerage for AI visibility. Write all recommendations in plain English for a brokerage owner.

Brokerage: ${brokerage_name}
Website: ${website_url}

Ledger data:
${ledgerText}

Produce a comprehensive AI visibility analysis:

1. Overall score (0-100) based on the 4 SALT pillars

2. SALT pillar scores (Semantic, Authority, Location, Trust) with:
   - Score (0-100)
   - One-sentence summary
   - 2-3 specific details explaining the score

3. 6-9 recommended actions with:
   - Clear, action-oriented title (e.g., "Add a page for each submarket you serve")
   - Which SALT pillar it affects
   - Priority (high/medium/low)
   - Affected URLs on the website
   - Issue: What's wrong or missing (1-2 sentences)
   - Why it matters: How this affects getting recommended (1-2 sentences)
   - What to do: Numbered steps (2-5 steps)
   - How to know you're done: Checklist items to verify completion

4. 8 intent coverage assessments. For each intent, evaluate whether the brokerage website has the content needed to be recommended when users ask these exact prompts:

   INTENT 1 — Local Landlord Representation
   Prompts: "Who should represent a landlord in Charleston commercial real estate?", "Local broker for commercial landlords in Charleston", "Best broker for small to mid-size landlords Charleston", "Do Charleston landlords need a local broker or a national firm?", "Who helps landlords reduce vacancy in Charleston?"

   INTENT 2 — Leasing Broker (Property-Type Specific)
   Prompts: "Who is the best broker to lease industrial space in Charleston?", "Commercial leasing agent for retail space Charleston", "Office leasing broker Charleston", "Who can lease my commercial building in Charleston?", "Leasing broker experienced with small commercial assets Charleston"

   INTENT 3 — Submarket Leasing Expertise
   Prompts: "Best broker to lease industrial space in North Charleston", "Commercial leasing agent Mount Pleasant retail", "Who understands Downtown Charleston office leasing?", "Local broker for North Charleston commercial properties", "Leasing challenges in Mount Pleasant commercial real estate"

   INTENT 4 — Tenant Representation (Local Businesses)
   Prompts: "Tenant representation broker Charleston", "Should a tenant use a broker in Charleston commercial real estate?", "Best tenant rep for small businesses in Charleston", "Who helps tenants negotiate commercial leases in Charleston?", "Is tenant representation worth it for retail tenants Charleston?"

   INTENT 5 — Property Management (Local Owners)
   Prompts: "Commercial property management for local owners Charleston", "Who should manage a strip center in Charleston?", "Local vs national property management Charleston", "Best property manager for small commercial portfolios Charleston", "Commercial property management Charleston retail and office"

   INTENT 6 — Local vs National Broker Decision
   Prompts: "Do I need CBRE or a local broker for my Charleston property?", "Local vs national commercial broker Charleston", "When does a local broker make more sense than CBRE?", "Is a national brokerage overkill for Charleston properties?", "Differences between local and national CRE brokers Charleston"

   INTENT 7 — Market Expertise & Changes
   Prompts: "What's changing in Charleston commercial real estate?", "Charleston commercial leasing trends", "Current tenant demand in Charleston commercial real estate", "Local insight on Charleston commercial market conditions", "What landlords should know about Charleston leasing right now"

   INTENT 8 — Development, Zoning & Constraints
   Prompts: "Who understands Charleston zoning for commercial projects?", "Commercial real estate development consultant Charleston", "Zoning and permitting challenges Charleston commercial real estate", "Who can advise on commercial development constraints Charleston?", "Local broker with development experience Charleston"

   For each intent return:
   - intent_name: Plain English name (e.g., "Local Landlord Representation")
   - Status: "Eligible" (content exists to be recommended), "Needs Work" (some content but gaps), or "Not Yet Eligible" (missing critical content—AI won't recommend you yet)
   - prompts: The exact prompts from above for this intent
   - solution_fixes: What specific content/pages are needed to become Eligible

5. 5-7 hyperspecific instructions with:
   - Simple ID (just a number or short name, NOT "R-01" format)
   - Clear title describing what to create or fix
   - Deliverable (what you'll have when done)
   - Impact level (high/medium/low)
   - Effort level (high/medium/low)
   - SALT points (1-5, how many SALT pillars this helps)
   - Target intent (the question someone would ask)
   - Target URL/page
   - Suggested title for the page/section
   - 4-8 specific action items
   - 2-4 things to avoid
   - Optional: good example text
   - Effect (e.g., "typically 30 days until search tools reflect changes")
   - Dependency (what needs to be in place first, or "None")

6. Prompt coverage (supported/missing/blocked prompts)

7. Market-specific content opportunity

8. Summary with blocking issues and key unlocks

9. Analysis summary with visibility snapshot, fix categories, and conclusion`;

    console.log("Analyzing brokerage:", brokerage_name);

    const response = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          tools: [
            {
              type: "function",
              function: {
                name: "return_analysis",
                description: "Return the complete AI visibility analysis",
                parameters: {
                  type: "object",
                  properties: {
                    overall_score: { type: "number" },
                    salt_scores: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          pillar: { type: "string", enum: ["Semantic", "Authority", "Location", "Trust"] },
                          score: { type: "number" },
                          summary: { type: "string" },
                          details: { type: "array", items: { type: "string" } },
                        },
                        required: ["pillar", "score", "summary", "details"],
                        additionalProperties: false,
                      },
                    },
                    recommended_actions: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string" },
                          title: { type: "string" },
                          pillar: { type: "string", enum: ["Semantic", "Authority", "Location", "Trust"] },
                          priority: { type: "string", enum: ["high", "medium", "low"] },
                          affected_urls: { type: "array", items: { type: "string" } },
                          issue: { type: "string" },
                          why_it_matters: { type: "string" },
                          what_to_do: { type: "array", items: { type: "string" } },
                          how_to_know_done: { type: "array", items: { type: "string" } },
                        },
                        required: ["id", "title", "pillar", "priority", "issue", "why_it_matters", "what_to_do", "how_to_know_done"],
                        additionalProperties: false,
                      },
                    },
                    intent_coverage: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          intent_id: { type: "string" },
                          intent_name: { type: "string" },
                          status: { type: "string", enum: ["Eligible", "Needs Work", "Not Yet Eligible"] },
                          prompts: { type: "array", items: { type: "string" } },
                          solution_fixes: {
                            type: "array",
                            items: {
                              type: "object",
                              properties: {
                                fix_name: { type: "string" },
                                description: { type: "string" },
                              },
                              required: ["fix_name", "description"],
                              additionalProperties: false,
                            },
                          },
                        },
                        required: ["intent_id", "intent_name", "status", "prompts", "solution_fixes"],
                        additionalProperties: false,
                      },
                    },
                    hyperspecific_instructions: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string" },
                          title: { type: "string" },
                          deliverable: { type: "string" },
                          impact: { type: "string", enum: ["high", "medium", "low"] },
                          effort: { type: "string", enum: ["high", "medium", "low"] },
                          salt_points: { type: "number" },
                          target_intent: { type: "string" },
                          target_url: { type: "string" },
                          suggested_title: { type: "string" },
                          action_items: { type: "array", items: { type: "string" } },
                          avoid: { type: "array", items: { type: "string" } },
                          good_example: { type: "string" },
                          effect: { type: "string" },
                          dependency: { type: "string" },
                        },
                        required: [
                          "id", "title", "deliverable", "impact", "effort", "salt_points",
                          "target_intent", "target_url", "suggested_title",
                          "action_items", "avoid", "effect",
                        ],
                        additionalProperties: false,
                      },
                    },
                    prompt_coverage: {
                      type: "object",
                      properties: {
                        supported: { type: "array", items: { type: "string" } },
                        missing: { type: "array", items: { type: "string" } },
                        blocked: { type: "array", items: { type: "string" } },
                      },
                      required: ["supported", "missing", "blocked"],
                      additionalProperties: false,
                    },
                    market_opportunity: {
                      type: "object",
                      properties: {
                        submarket: { type: "string" },
                        suggested_title: { type: "string" },
                        headings_description: { type: "string" },
                        required_content: { type: "array", items: { type: "string" } },
                        avoid: { type: "array", items: { type: "string" } },
                      },
                      required: ["submarket", "suggested_title", "headings_description", "required_content", "avoid"],
                      additionalProperties: false,
                    },
                    summary: {
                      type: "object",
                      properties: {
                        blocking_issues: { type: "array", items: { type: "string" } },
                        key_unlocks: { type: "array", items: { type: "string" } },
                      },
                      required: ["blocking_issues", "key_unlocks"],
                      additionalProperties: false,
                    },
                    analysis_summary: {
                      type: "object",
                      properties: {
                        visibility_snapshot: { type: "array", items: { type: "string" } },
                        fix_categories: { type: "array", items: { type: "string" } },
                        conclusion: { type: "string" },
                      },
                      required: ["visibility_snapshot", "fix_categories", "conclusion"],
                      additionalProperties: false,
                    },
                  },
                  required: [
                    "overall_score", "salt_scores", "recommended_actions",
                    "intent_coverage", "hyperspecific_instructions",
                    "prompt_coverage", "market_opportunity", "summary", "analysis_summary",
                  ],
                  additionalProperties: false,
                },
              },
            },
          ],
          tool_choice: { type: "function", function: { name: "return_analysis" } },
        }),
      }
    );

    if (!response.ok) {
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage limit reached. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      throw new Error(`AI gateway returned ${response.status}`);
    }

    const aiData = await response.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("No structured response from AI");

    const analysis = JSON.parse(toolCall.function.arguments);
    console.log("Analysis complete, overall score:", analysis.overall_score);

    return new Response(JSON.stringify(analysis), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze-ledger error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
