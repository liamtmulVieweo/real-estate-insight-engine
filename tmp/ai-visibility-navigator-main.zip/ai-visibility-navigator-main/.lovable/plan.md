

# Fix Runtime Errors

## Root Causes

There are three sources of intermittent runtime errors:

1. **ScanForm missing forwardRef** -- Radix UI Tabs tries to attach a ref to ScanForm. Without `forwardRef`, React throws a warning that can cascade into rendering issues.

2. **Fragile AI response parsing** -- The AI model sometimes returns incomplete or differently-shaped data. The frontend assumes every field exists (e.g., `analysis.salt_scores.map(...)`, `coverage.blocked`), which crashes when a field is missing or null.

3. **Edge function "No structured response" error** -- Sometimes the AI gateway doesn't return a valid tool call. The edge function throws, but the frontend error handling could be more robust.

## Fixes

### Fix 1: Add forwardRef to ScanForm
- Wrap `ScanForm` with `React.forwardRef` so Radix UI Tabs can attach its ref without errors.

### Fix 2: Add defensive access throughout analysis components
- Add optional chaining and default values to every analysis component:
  - `OverallScore.tsx`: default `saltScores` to `[]`
  - `RecommendedActions.tsx`: default `actions` to `[]`
  - `IntentMonitoring.tsx`: default `intents` to `[]`
  - `PromptCoverageSection.tsx`: default `coverage.supported/missing/blocked` to `[]`
  - `HyperspecificInstructions.tsx`: default `instructions` to `[]`
  - `MarketOpportunitySection.tsx`: guard all nested fields
  - `SummarySection.tsx`: guard all nested fields
  - `AnalysisView.tsx`: add a null guard -- if `analysis` is missing critical fields, show a fallback message instead of crashing

### Fix 3: Improve error handling in the hook
- In `useBrokerageScan.ts`, add a try/catch around the JSON parsing of the analysis result
- If the response is missing expected fields, set a user-friendly error instead of crashing

### Technical Details
- All changes are purely frontend defensive coding -- no backend or schema changes needed
- The edge function already handles the error case and returns `{ error: "..." }`, so the frontend just needs to catch it properly

